type ViewMode = {
  clock;
  calendar;
  months;
  years;
  decades;
};

export default ViewMode;
