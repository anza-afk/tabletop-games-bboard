declare type ViewMode = {
    clock: any;
    calendar: any;
    months: any;
    years: any;
    decades: any;
};
export default ViewMode;
