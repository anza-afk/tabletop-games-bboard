import Options from './options';
declare const DefaultOptions: Options;
export default DefaultOptions;
